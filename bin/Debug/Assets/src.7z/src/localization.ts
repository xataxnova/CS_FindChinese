class localization {
    static string_1:string = "KonNiTiHa";
}