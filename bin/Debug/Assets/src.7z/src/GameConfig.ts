/*
* 游戏初始化配置;
*/
class GameConfig{
    static width:number=1136;
    static height:number=640;
    static scaleMode:string="showall";
    static screenMode:string="none";
    static alignV:string="top";
    static alignH:string="left";
    static startScene:any=ui.reviveUI;
    static sceneRoot:string="";
    static debug:boolean=false;
    static stat:boolean=false;
    constructor(){

    }
}